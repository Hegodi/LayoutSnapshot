Known Issues:

- Navigators: 
	Only one window can be detected (the last one being interacted with). 
	Microsoft Edge: Will fail to open it (if not already opened) if Edge was already closed in the same session. 
- File Explorer: 
	Windows of this type are not detected
